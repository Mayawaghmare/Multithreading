/**
 * 
 */
/**
 * @author This PC
 *
 */
module multithreading {
	requires java.desktop;
}