package com.jspiders.multithreading.threads;

public class MyThread2 implements Runnable {
	@Override
	public void run() {
		for (int i = 0; i <=5; i++) {
			System.out.println("THREAD 2 NOW WILL BE RUNNING...");
			
		}
	}

	public void setPriority(int i) {
		
	}

}
