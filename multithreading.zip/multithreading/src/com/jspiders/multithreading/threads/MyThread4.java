package com.jspiders.multithreading.threads;

public class MyThread4  extends Thread{
	@Override
	public void run() {
		System.out.println("THREAD 4 IS RUNNING NOW...");
		super.run();
	}

}
